Letakkan foto ulang tahun di folder ini dan beri nama birthday-photo.jpg.
